function startSewa() {
  const sewaId = document.getElementById('sewaId').value;
  const nama = document.getElementById('nama').value;
  const durasi = document.getElementById('durasi').value;

  fetch(`/api/start?sewaId=${sewaId}&nama=${nama}&durasi=${durasi}`)
    .then(res => res.json())
    .then(data => alert(data.message))
    .catch(err => console.error(err));
}

function stopSewa() {
  const sewaId = document.getElementById('sewaId').value;

  fetch(`/api/stop?sewaId=${sewaId}`)
    .then(res => res.json())
    .then(data => alert(data.message))
    .catch(err => console.error(err));
}