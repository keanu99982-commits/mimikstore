export default function handler(req, res) {
  const { id, nama, durasi } = req.query; // data dari front-end / bot
  // Simulasi proses sewa WA
  console.log(`Start sewa: ${id} - ${nama} - ${durasi}`);
  res.status(200).json({ message: 'Sewa WA dimulai!' });
}