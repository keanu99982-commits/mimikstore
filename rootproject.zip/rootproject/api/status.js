export default function handler(req, res) {
  const { sewaId } = req.query;
  if (!sewaId) return res.status(400).json({ error: 'ID wajib diisi!' });
  const status = Math.random() > 0.5 ? 'aktif' : 'tidak aktif';
  res.status(200).json({ sewaId, status });
}