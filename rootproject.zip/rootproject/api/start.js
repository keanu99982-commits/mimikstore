export default function handler(req, res) {
  const { sewaId, nama, durasi } = req.query;
  if (!sewaId || !nama || !durasi) {
    return res.status(400).json({ error: 'ID, nama, dan durasi wajib diisi!' });
  }
  console.log(`Start sewa: ${sewaId} - ${nama} - ${durasi}`);
  res.status(200).json({ message: `Sewa WA dimulai untuk ${nama} selama ${durasi}!` });
}