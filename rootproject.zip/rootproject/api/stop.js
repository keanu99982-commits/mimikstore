export default function handler(req, res) {
  const { sewaId } = req.query;
  if (!sewaId) return res.status(400).json({ error: 'ID wajib diisi!' });
  console.log(`Stop sewa: ${sewaId}`);
  res.status(200).json({ message: `Sewa WA dengan ID ${sewaId} dihentikan.` });
}