import express from 'express';
import fs from 'fs';
import path from 'path';
import cors from 'cors';

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.static(path.join(path.resolve(), 'public')));

// File JSON untuk simpan saldo sementara
const saldoFile = path.join(path.resolve(), 'saldo.json');

// Inisialisasi saldo
if (!fs.existsSync(saldoFile)) {
  fs.writeFileSync(saldoFile, JSON.stringify({ saldo: 0 }));
}

// Fungsi baca saldo
const readSaldo = () => {
  const data = fs.readFileSync(saldoFile);
  return JSON.parse(data).saldo;
};

// Fungsi update saldo
const updateSaldo = (amount) => {
  const current = readSaldo();
  fs.writeFileSync(saldoFile, JSON.stringify({ saldo: current + amount }));
};

// Tambah saldo 300p setiap 20 detik
setInterval(() => {
  updateSaldo(300);
  console.log(`Saldo bertambah 300p, total: ${readSaldo()}`);
}, 20000);

// Endpoint cek saldo
app.get('/api/saldo', (req, res) => {
  res.json({ saldo: readSaldo() });
});

// Endpoint start sewa (dummy)
app.get('/api/start', (req, res) => {
  const { sewaId, nama, durasi } = req.query;
  if (!sewaId || !nama || !durasi) return res.status(400).json({ error: 'ID, nama, durasi wajib diisi!' });
  res.json({ message: `Sewa WA dimulai untuk ${nama} selama ${durasi}` });
});

// Endpoint stop sewa (dummy)
app.get('/api/stop', (req, res) => {
  const { sewaId } = req.query;
  if (!sewaId) return res.status(400).json({ error: 'ID wajib diisi!' });
  res.json({ message: `Sewa WA dengan ID ${sewaId} dihentikan.` });
});

app.listen(PORT, () => console.log(`Server ready di http://localhost:${PORT}`));